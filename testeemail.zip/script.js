/*function sendMail() {
    var link = "mailto:vander.quintanilha@soulasalle.com.br"
             + "&subject=" + escape("This is my subject")
             + "&body=" + escape(document.getElementById('myText').value)
    ;

    window.location.href = link;
}*/

function Send()
{
  console.log("Yeh");
  // This doesnt work right now because the password is incorrect. You can follow instruction at SMTPJS.com. It also didnt work for me through Codepen.io, I had to download the project, and it worked when I opened the index.html file on my local computer
  Email.send({
          Host : "smtp.elasticemail.com",
          Username : "vander.quintanilha@soulasalle.com.br",
          Password : "9dab2617-d450-49df-9258-dbed2a668f13",
          To : 'vander2014quintanilha@gmail.com',
          From : "vander.quintanilha@soulasalle.com.br",
          Subject : "This is the subject",
          Body : "And this is the body"
      })
    .then(message => alert(message));

}


